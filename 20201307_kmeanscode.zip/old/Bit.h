 #ifndef TRY_BIT_H
#define TRY_BIT_H


//class Bit {
//    bool value;
//
//public:
//    Bit(bool);
//    Bit(short);
////    basic_string<_CharT, _Traits, _Alloc> std::operator+(_CharT __lhs,
////                                                         const std::basic_string<_CharT, _Traits, _Alloc> &__rhs) {}
//
//};


#endif //TRY_BIT_H
