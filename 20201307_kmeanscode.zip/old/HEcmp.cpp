

#include "HEcmp.h"


/*
 * 0.
 * todo i need an object initialized with the params
 *
 *      0.0
 *      todo C'tor - an empty one (default valuse)
 *      0.1
 *      todo C'tor - an non-empty one  -  maybe more than one
 *
 * 1.
 * todo this object will then be able to compare to encrypted numbers and return a boolean answer
 *
 *      1.0
 *      todo create a function with 2 arguments a and b
 *      1.1
 *      todo the function reurns true if a>b, and false otherwise
 *
 *
 */

