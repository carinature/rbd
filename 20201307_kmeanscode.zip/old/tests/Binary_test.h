

#ifndef TRY_BINARY_TEST_H
#define TRY_BINARY_TEST_H

//#include "../Binary.h"

using Binary = long;
class Binary_test {

public:
    static void mini_test();
};


#endif //TRY_BINARY_TEST_H
