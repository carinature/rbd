

#ifndef TRY_SKEYS_TEST_H
#define TRY_SKEYS_TEST_H


#include "../Skeys.h"


class Skeys_test {

public:
    static void skeys_mini_test();
    static void skeys_test_ctor();
    static void skeys_test_dtor();
    static void skeys_test_decrypt();
    static void skeys_test_g_cmp();

};


#endif //TRY_SKEYS_TEST_H
