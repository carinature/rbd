
#ifndef TRY_KEYSSERVER_TEST_H
#define TRY_KEYSSERVER_TEST_H


class KeysServer_test {
public:
//    static void mini_test();
    static void test_ctor();
    static void test_dtor();
    static void run_all();

};



#endif //TRY_KEYSSERVER_TEST_H
