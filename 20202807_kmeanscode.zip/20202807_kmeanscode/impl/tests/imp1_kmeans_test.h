

#ifndef TRY_IMP1_KMEANS_TEST_H
#define TRY_IMP1_KMEANS_TEST_H


class imp1_kmeans_test {
public:
    static void getEncryptedKMeansTestNew();
    
    static void getLeftoverPointsTest();
    
    static void calculateThresholdTest();
    
    static void run_all();
    
    
/*
* Deprecated
* */
    static void getEncryptedKMeansTest();
    
};


#endif //TRY_IMP1_KMEANS_TEST_H
