

#ifndef TRY_RUN_TESTS_H
#define TRY_RUN_TESTS_H

#include "KeysServer_test.h"
#include "Point_test.h"
#include "aux_test.h"
#include "imp1_kmeans_test.h"


#endif //TRY_RUN_TESTS_H
